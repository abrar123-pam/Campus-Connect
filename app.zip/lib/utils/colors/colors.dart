import 'dart:ui';

class TColors{
  static const Color appColor1 = Color(0xff0E4192);
}