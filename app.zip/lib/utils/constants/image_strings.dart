class TImages{
  static const String promoBanner1 = 'images/Events/circular.jpeg';
  static const String promoBanner2 = 'images/Events/iitm.jpeg';
  static const String promoBanner3 = 'images/Events/hiring.jpeg';
  static const String promoBanner4 = 'images/Events/sathak.jpeg';

}